/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package test;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.StringTokenizer;


public class LoadingProb 
{
    public HashMap origin_news;
    public HashMap category_news;
    public HashMap about_person;
    public HashMap news_made;
           

     public LoadingProb() throws FileNotFoundException
    {
        origin_news=getLoadedList("origin_of_news.txt");
        category_news=getLoadedList("category.txt");
        about_person=getLoadedList("about_person.txt");
        news_made=getLoadedList("news_made_prob.txt");
 
    }
         
    public HashMap<String,Integer> getLoadedList(String fileName) throws FileNotFoundException
    {
       HashMap<String,Integer> loadedList=new HashMap<String,Integer>();
        try
        {
            BufferedReader br = new BufferedReader(new FileReader(fileName));
            String line;
            while ((line = br.readLine()) != null) 
            {
             StringTokenizer st=new StringTokenizer(line,":");
             String person=st.nextToken();
             int prob=Integer.parseInt(st.nextToken());
             loadedList.put(person, prob);
              }
          }
        catch(Exception e)
        {
            System.out.println(""+e);
        }
    
         return loadedList;
    }
            
     
 }

    

