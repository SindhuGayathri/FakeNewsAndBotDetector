/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package FakeNewsDetector;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.StringTokenizer;

 public class FakePercentageRead {
    public static void main(String[] args) throws FileNotFoundException, IOException 
    {
        ArrayList<OriginNewsData> news=FakePercentageRead.getLoadedList("origin_of_news.txt");
        for(OriginNewsData d:news)
        {
        System.out.println(d.field);
        System.out.println(d.prob);
        }
         
         
        
        
        
   }
    
  public static int getRandom(int length)
  {
  int n=(int)(Math.floor(Math.random()*length));
  return n;
  }
  public static String getRandomString(ArrayList<String> a)
  {
        String s1=a.get(FakePercentageRead.getRandom(a.size()));
        return s1;
  }
  public static String getRandomString(ArrayList<String> a,int index)
  {
        String s1=a.get(index);
        return s1;
  }
    
  public static void printTime()
   {
         Timestamp timestamp = new Timestamp(System.currentTimeMillis());
        System.out.print(" "+timestamp);

   }
    
    
    
    
    public static ArrayList<OriginNewsData> getLoadedList(String fileName) throws FileNotFoundException
    {
        ArrayList<OriginNewsData> loadedList=new ArrayList<OriginNewsData>();
        try
        {
            BufferedReader br = new BufferedReader(new FileReader(fileName));
            String line;
            while ((line = br.readLine()) != null) 
            {
    //        System.out.println(""+line);
            loadedList.add(new OriginNewsData(line));
            }
         }
        catch(Exception e)
        {
        }
    
         return loadedList;
    }
 }
class OriginNewsData
{
public String  field;
public int prob;
public OriginNewsData(String data)
{
StringTokenizer st=new StringTokenizer(data,":");
field=st.nextToken();
prob=Integer.parseInt(st.nextToken());
   // System.out.println(field+""+prob);    
}

}

