/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package FakeNewsDetector;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Timestamp;
import java.util.ArrayList;

 public class Testing {
    public static void main(String[] args) throws FileNotFoundException, IOException 
    {
        ArrayList<String> news_made=Testing.getLoadedList("news_made.txt");
        ArrayList<String> origin_of_news=Testing.getLoadedList("origin_of_news.txt");
        ArrayList<String> category=Testing.getLoadedList("category.txt");

        while(true){
        System.out.print(""+getRandomString(origin_of_news));
        System.out.print(","+getRandomString(news_made));
        System.out.print(","+getRandomString(news_made));
        System.out.print(",person"+getRandom(100)+","+"person"+getRandom(100));
        System.out.print(",topic"+getRandom(100));
        int dec=getRandom(2);
        if(dec==0)
        {
            System.out.print(",Negative,");
        }
        else
        {
            System.out.print(",Positive,");
         }
         printTime();
        System.out.println("");
 }
   }
  public static int getRandom(int length)
  {
  int n=(int)(Math.floor(Math.random()*length));
  return n;
  }
  public static String getRandomString(ArrayList<String> a)
  {
        String s1=a.get(Testing.getRandom(a.size()));
        return s1;
  }
    
    
   public static void printTime()
   {
         Timestamp timestamp = new Timestamp(System.currentTimeMillis());
        System.out.print(" "+timestamp);

   }
    
    
    
    
    public static ArrayList<String> getLoadedList(String fileName) throws FileNotFoundException
    {
        ArrayList<String> loadedList=new ArrayList<String>();
        try
        {
            BufferedReader br = new BufferedReader(new FileReader(fileName));
            String line;
            while ((line = br.readLine()) != null) 
            {
    //        System.out.println(""+line);
            loadedList.add(line);
            }
         }
        catch(Exception e)
        {
        }
    
         return loadedList;
    }
 }

