/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package FakeNewsDetector;

import java.sql.Timestamp;
import java.time.format.DateTimeFormatter;
import java.util.StringTokenizer;

/**
 *
 * @author Lenovo
 */
public class timestampdemo {

    public static void main(String args[])
    {
        String time="2017-11-06 06:36:39.362";
        String aftertime="2017-11-06 06:35:39.214";
         Timestamp t=getTimestamp(time);
         Timestamp t1=getTimestamp(aftertime);
         System.out.println(""+t.after(t1));
        System.out.println(""+t.before(t1));

     }
 public static Timestamp getTimestamp(String time)
 {
        StringTokenizer st=new StringTokenizer(time," :-.");
        int year=Integer.parseInt(st.nextToken());
        int month=Integer.parseInt(st.nextToken());
        int day=Integer.parseInt(st.nextToken());
        int hour=Integer.parseInt(st.nextToken());
        int minute=Integer.parseInt(st.nextToken());
        int sec=Integer.parseInt(st.nextToken());
        int nano=Integer.parseInt(st.nextToken());
        Timestamp t=new Timestamp(year, month, day, hour, minute, sec, nano);
        return t;
  }
    
    
}
