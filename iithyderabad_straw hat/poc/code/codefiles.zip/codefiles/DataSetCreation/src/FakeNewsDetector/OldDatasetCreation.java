/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package FakeNewsDetector;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Timestamp;
import java.util.ArrayList;
import javax.swing.JOptionPane;

 public class OldDatasetCreation {
    public static void main(String[] args) throws FileNotFoundException, IOException 
    {
        FakeNewsDetector f=new FakeNewsDetector();
        f.setVisible(true);
    }
  public static int getRandom(int length)
  {
  int n=(int)(Math.floor(Math.random()*length));
  return n;
  }
  public static String getRandomString(ArrayList<String> a)
  {
        String s1=a.get(OldDatasetCreation.getRandom(a.size()));
        return s1;
  }
    
    
   public static void printTime()
   {
         Timestamp timestamp = new Timestamp(System.currentTimeMillis());
        System.out.print(" "+timestamp);

   }
    
    
    
    
    public static ArrayList<String> getLoadedList(String fileName) throws FileNotFoundException
    {
        ArrayList<String> loadedList=new ArrayList<String>();
        try
        {
            BufferedReader br = new BufferedReader(new FileReader(fileName));
            String line;
            while ((line = br.readLine()) != null) 
            {
    //        System.out.println(""+line);
            loadedList.add(line);
            }
         }
        catch(Exception e)
        {
        }
    
         return loadedList;
    }
 }

