/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package FakeNewsDetector;

import java.util.StringTokenizer;

/**
 *
 * @author Lenovo
 */
public class DataSet {
    public String person;
    public String field;
     
    public DataSet(String data)
    {
    StringTokenizer st=new StringTokenizer(data,">");
    String person=st.nextToken();
    String field=st.nextToken();
    this.person=person;
    this.field=field;
        System.out.print(person+" "+field);
     }
    
}
