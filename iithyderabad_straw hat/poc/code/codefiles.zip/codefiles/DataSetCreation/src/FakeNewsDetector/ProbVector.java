/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package FakeNewsDetector;


public class ProbVector 
{
    public float prob_orgin;
    public float prob_bywhom;
    public float prob_sender;
    public float prob_catagory;
    public int isfake;
     
    public ProbVector(float prob_origin,float prob_bywhom,float prob_sender,float prob_catagory,int isfake)
    {
    this.isfake=isfake;
    this.prob_orgin=prob_origin;
    this.prob_sender=prob_sender;
    this.prob_bywhom=prob_bywhom;
    this.prob_catagory=prob_catagory;
    }
    public ProbVector()
    {
    }
    public void display()
    {
        System.out.print("("+isfake);
        System.out.print(","+prob_orgin);
        System.out.print(","+prob_sender);
        System.out.print(","+prob_bywhom);
        System.out.println(","+prob_catagory+")");
    }
    public String toString()
    {
        String x="("+isfake+","+prob_orgin+","+prob_sender+","+prob_catagory+")";
        return x;
    }
    
    
}
