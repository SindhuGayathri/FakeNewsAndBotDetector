/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package FakeNewsDetector;

import static FakeNewsDetector.DatasetRead.getProbVectors;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import test.LoadingProb;

/**
 *
 * @author Lenovo
 */
public class TrainDetector {
       public ArrayList<DataRecord> data_set;
       public LoadingProb loadingProb;
       public ProbVector truemean=null;
       public ProbVector fakemean=null;
     
    
     public   void Train(String Filepath) throws FileNotFoundException
    {
       data_set=DatasetRead.getLoadedList(Filepath);
       loadingProb=new LoadingProb();
       ProbVector prev_true_prob=null,prev_fake_prob=null;
       int dec=0;
       ArrayList<ProbVector> probVectors=getProbVectors(data_set, loadingProb);
       int need_break1=0,need_break2=0;
       truemean=null;
       fakemean=null;
       boolean convergent=false;
      //////////////////////////////////////////////////////////////////
       while(!convergent)
       {    
            int i=0;
            int no_true=0;
            int no_fake=0;
            float true_orgprob=0; 
            float true_bywhomprob=0;   
            float true_sendprob=0;    
            float true_catgoryprob=0;
            float fake_orgprob=0; 
            float fake_bywhomprob=0;   
            float fake_sendprob=0;    
            float fake_catgoryprob=0;
                       

        for(ProbVector p:probVectors)
        {
            
          if(p.isfake==0)
          {  
             true_orgprob+=p.prob_orgin;
             true_bywhomprob+=p.prob_bywhom;   
             true_sendprob+=p.prob_sender;   
             true_catgoryprob+=p.prob_catagory;
             no_true++;
          }
          else
          {
             fake_orgprob+=p.prob_orgin;
             fake_bywhomprob+=p.prob_bywhom;   
             fake_sendprob+=p.prob_sender;   
             fake_catgoryprob+=p.prob_catagory;
             no_fake++;
           }
        }
        //System.out.println("no of true"+no_true);
        //.out.println("no of fake"+no_fake);
 
        true_orgprob=(true_orgprob)/no_true;
        true_bywhomprob=(true_bywhomprob)/no_true;
        true_sendprob=(true_sendprob)/no_true;
        true_catgoryprob=true_catgoryprob/no_true ;
        
        fake_orgprob=(fake_orgprob)/no_fake;
        fake_bywhomprob=(fake_bywhomprob)/no_fake;
        fake_sendprob=(fake_sendprob)/no_fake;
        fake_catgoryprob=fake_catgoryprob/no_fake ;
        
        truemean=new ProbVector(true_orgprob,true_bywhomprob,true_sendprob,true_catgoryprob,0);
        fakemean=new ProbVector(fake_orgprob,fake_bywhomprob,fake_sendprob,fake_catgoryprob,1);
        
       // System.out.println("Current-Centeroids");
        /////////////////////////////////////////////////////////////////////////////
          // System.out.println("true");
           //truemean.display();
           //System.out.println("fake");
           //fakemean.display();
        //////////////////////////////////////////////////////////////////////////////
        float distance=getDistance(fakemean,truemean);
        
        for(int index=0;index<probVectors.size();index++)
        {
            float dist1= getDistance(probVectors.get(index),truemean);
            float dist2=getDistance(probVectors.get(index),fakemean);
           // System.out.println("("+dist1+","+dist2+")");
            if(dist1<dist2)
            {
                probVectors.get(index).isfake=0;
                data_set.get(index).fake="true";
                
            }
            else
            {
                probVectors.get(index).isfake=1;
                data_set.get(index).fake="fake";

            }
        
        }
        
        //////////////////////////////////////////////////////////////////////////////
         if(dec==0)
         {
             prev_fake_prob=fakemean;
             prev_true_prob=truemean;
             dec=1;
         }
         else
         {
             //System.out.println("PrevCentroids fake:");
             //prev_fake_prob.display();
             //System.out.println("trueCenriod");
             //prev_true_prob.display();
		float true_error_rate_org=prev_true_prob.prob_orgin-truemean.prob_orgin;
             float true_error_rate_bywhom=prev_true_prob.prob_bywhom-truemean.prob_bywhom;
             float true_error_rate_cat=prev_true_prob.prob_catagory-truemean.prob_catagory;
             float true_error_rate_send=prev_true_prob.prob_sender-truemean.prob_sender;
             float fake_error_rate_org=prev_fake_prob.prob_orgin-fakemean.prob_orgin;
             float fake_error_rate_bywhom=prev_fake_prob.prob_bywhom-fakemean.prob_bywhom;
             float fake_error_rate_cat=prev_fake_prob.prob_catagory-fakemean.prob_catagory;
             float fake_error_rate_send=prev_fake_prob.prob_sender-fakemean.prob_sender;
 
             true_error_rate_bywhom=getAbs(true_error_rate_bywhom);
             true_catgoryprob=getAbs(true_catgoryprob);
             true_error_rate_cat=getAbs(true_error_rate_cat);
             true_error_rate_send=getAbs(true_error_rate_send);
             fake_error_rate_bywhom=getAbs(fake_error_rate_bywhom);
             fake_catgoryprob=getAbs(fake_catgoryprob);
             fake_error_rate_cat=getAbs(fake_error_rate_cat);
             fake_error_rate_send=getAbs(fake_error_rate_send);
             
             
             if(  (true_error_rate_bywhom<=0.01)&&(true_error_rate_org<=0.01)&&(true_error_rate_cat<=0.01)&&(true_error_rate_send<=0.01))
             {
             need_break1=1;
             }
              
            
 
             if(  (fake_error_rate_bywhom<=0.01)&&(fake_error_rate_org<=0.01)&&(fake_error_rate_cat<=0.01)&&(fake_error_rate_send<=0.01))
             {
             need_break2=1;
             }
             if(need_break1==1&&need_break2==1)
             {
             break;
             }
             
             
             prev_fake_prob=fakemean;
             prev_true_prob=truemean;
         
         }
         
        
       }
               System.out.println("***********Cluster-Report***************");
               truemean.display();
               fakemean.display();
    }
    
       public  float getDistance(ProbVector p1,ProbVector p2)
    {
        float distance=(float) Math.pow((p1.prob_orgin-p2.prob_orgin),2);
        distance+=(float) Math.pow((p1.prob_bywhom-p2.prob_bywhom),2);
        distance+=(float) Math.pow((p1.prob_catagory-p2.prob_catagory),2);
        distance+=(float) Math.pow((p1.prob_sender-p2.prob_sender),2);
        distance=(float)Math.sqrt(distance);
        return distance;
    }
       private  float getAbs(float x)
       {
           if(x<0){
           return -1*x;
           }
           return x;
       
       }
 
    
    
}
