/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package FakeNewsDetector;
import javax.swing.*;

/**
 *
 * @author Lenovo
 */
public class JFileChooserDemo {
    
    public static void main(String args[])
    {
    JFileChooser j=new JFileChooser();
    j.showOpenDialog(null);
    System.out.println(""+j.getSelectedFile().getPath());
    
    
    }
    
    
}
